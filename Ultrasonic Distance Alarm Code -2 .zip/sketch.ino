// Ultrasonic Distance Alarm
// Arduino Uno + HC-SR04 + Red LED + Green LED + Buzzer

const int trigPin = 9;
const int echoPin = 10;

const int redLED = 6;
const int greenLED = 5;
const int buzzer = 3;

long duration;
int distance;

void setup() {
  pinMode(trigPin, OUTPUT);
  pinMode(echoPin, INPUT);

  pinMode(redLED, OUTPUT);
  pinMode(greenLED, OUTPUT);
  pinMode(buzzer, OUTPUT);

  Serial.begin(9600);
}

void loop() {

  // Ultrasonic sensor ko signal bhejna
  digitalWrite(trigPin, LOW);
  delayMicroseconds(2);

  digitalWrite(trigPin, HIGH);
  delayMicroseconds(10);

  digitalWrite(trigPin, LOW);

  // Echo signal read karna
  duration = pulseIn(echoPin, HIGH);

  // Distance calculate karna
  distance = duration * 0.034 / 2;

  Serial.print("Distance: ");
  Serial.print(distance);
  Serial.println(" cm");

  // Agar object 20 cm ke andar hai
  if (distance > 0 && distance <= 20) {

    digitalWrite(redLED, HIGH);
    digitalWrite(greenLED, LOW);

    tone(buzzer, 1000);
  }

  // Agar object 20 cm se door hai
  else {

    digitalWrite(redLED, LOW);
    digitalWrite(greenLED, HIGH);

    noTone(buzzer);
  }

  delay(200);
}