// Ultrasonic Distance Alarm
// Arduino Uno + HC-SR04 + Red LED + Green LED + Buzzer

const int trigPin = 9;
const int echoPin = 10;

const int redLED = 6;
const int greenLED = 5;
const int buzzer = 3;

long duration;
int distance;

void setup() {
  pinMode(trigPin, OUTPUT);
  pinMode(echoPin, INPUT);

  pinMode(redLED, OUTPUT);
  pinMode(greenLED, OUTPUT);
  pinMode(buzzer, OUTPUT);

  Serial.begin(9600);
}

void loop() {
  // Send ultrasonic pulse
  digitalWrite(trigPin, LOW);
  delayMicroseconds(2);

  digitalWrite(trigPin, HIGH);
  delayMicroseconds(10);
  digitalWrite(trigPin, LOW);

  // Read echo
  duration = pulseIn(echoPin, HIGH);

  // Calculate distance in cm
  distance = duration * 0.034 / 2;

  Serial.print("Distance: ");
  Serial.print(distance);
  Serial.println(" cm");

  // If obstacle is close
  if (distance <= 20) {
    digitalWrite(redLED, HIGH);
    digitalWrite(greenLED, LOW);

    tone(buzzer, 1000);
  }
  // If obstacle is far
  else {
    digitalWrite(redLED, LOW);
    digitalWrite(greenLED, HIGH);

    noTone(buzzer);
  }

  delay(200);
}