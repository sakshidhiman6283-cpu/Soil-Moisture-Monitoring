const int buzzer = 8;

const int buttons[8] = {2, 3, 4, 5, 6, 7, 9, 10};

const int notes[8] = {
  262, // C
  294, // D
  330, // E
  349, // F
  392, // G
  440, // A
  494, // B
  523  // C
};

void setup() {
  for (int i = 0; i < 8; i++) {
    pinMode(buttons[i], INPUT_PULLUP);
  }
}

void loop() {
  bool playing = false;

  for (int i = 0; i < 8; i++) {
    if (digitalRead(buttons[i]) == LOW) {
      tone(buzzer, notes[i]);
      playing = true;
      break;
    }
  }

  if (!playing) {
    noTone(buzzer);
  }
}