const int LDR_PIN = A0;
const int LED_PIN = 13;

void setup() {
  pinMode(LED_PIN, OUTPUT);
  Serial.begin(9600);
}

void loop() {
  int lightValue = analogRead(LDR_PIN);

  Serial.println(lightValue);

  // Andhera hone par LED ON
  if (lightValue < 500) {
    digitalWrite(LED_PIN, HIGH);
  } 
  // Roshni hone par LED OFF
  else {
    digitalWrite(LED_PIN, LOW);
  }

  delay(100);
}