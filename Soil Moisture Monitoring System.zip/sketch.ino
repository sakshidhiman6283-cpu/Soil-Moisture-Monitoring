const int soilPin = A0;
const int greenLED = 7;
const int redLED = 8;
const int buzzer = 9;

void setup() {
  pinMode(greenLED, OUTPUT);
  pinMode(redLED, OUTPUT);
  pinMode(buzzer, OUTPUT);

  Serial.begin(9600);
}

void loop() {
  int moisture = analogRead(soilPin);

  Serial.print("Soil Moisture: ");
  Serial.println(moisture);

  if (moisture < 400) {
    // Dry soil
    digitalWrite(redLED, HIGH);
    digitalWrite(greenLED, LOW);
    tone(buzzer, 1000);
  } 
  else {
    // Wet soil
    digitalWrite(redLED, LOW);
    digitalWrite(greenLED, HIGH);
    noTone(buzzer);
  }

  delay(500);
}