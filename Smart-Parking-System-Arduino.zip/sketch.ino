#include <Servo.h>

// Pin Definitions
const int trigPin = 10;
const int echoPin = 11;

const int servoPin = 9;
const int greenLED = 7;
const int redLED = 6;
const int buzzer = 8;

Servo gateServo;

long duration;
int distance;

void setup() {
  pinMode(trigPin, OUTPUT);
  pinMode(echoPin, INPUT);

  pinMode(greenLED, OUTPUT);
  pinMode(redLED, OUTPUT);
  pinMode(buzzer, OUTPUT);

  gateServo.attach(servoPin);

  // Initial State
  gateServo.write(0);
  digitalWrite(greenLED, LOW);
  digitalWrite(redLED, HIGH);
  noTone(buzzer);

  Serial.begin(9600);
}

void loop() {

  // Send ultrasonic signal
  digitalWrite(trigPin, LOW);
  delayMicroseconds(2);

  digitalWrite(trigPin, HIGH);
  delayMicroseconds(10);

  digitalWrite(trigPin, LOW);

  // Read echo
  duration = pulseIn(echoPin, HIGH);

  // Calculate distance
  distance = duration * 0.034 / 2;

  Serial.print("Distance: ");
  Serial.print(distance);
  Serial.println(" cm");

  // Vehicle detected
  if (distance < 10) {

    // Open gate
    gateServo.write(90);

    // Green LED ON
    digitalWrite(greenLED, HIGH);

    // Red LED OFF
    digitalWrite(redLED, LOW);

    // Buzzer ON
    tone(buzzer, 1000);

  } else {

    // Close gate
    gateServo.write(0);

    // Green LED OFF
    digitalWrite(greenLED, LOW);

    // Red LED ON
    digitalWrite(redLED, HIGH);

    // Buzzer OFF
    noTone(buzzer);
  }

  delay(200);
}